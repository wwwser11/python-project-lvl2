from gendiff.scripts.cli import run


def main():
    args = run()


if __name__ == '__main__':
    main()